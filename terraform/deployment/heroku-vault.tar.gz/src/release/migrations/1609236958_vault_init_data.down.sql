DROP TABLE IF EXISTS vault_init_data;
