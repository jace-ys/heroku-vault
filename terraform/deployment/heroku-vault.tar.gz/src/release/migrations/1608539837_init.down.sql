DROP TABLE IF EXISTS vault_kv_store;
DROP INDEX IF EXISTS parent_path_idx;
